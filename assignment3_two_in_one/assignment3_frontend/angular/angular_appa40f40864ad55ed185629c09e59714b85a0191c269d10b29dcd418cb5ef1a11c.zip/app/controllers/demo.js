app.controller("demo",function($scope){
    $scope.fname = "Tanvir";
});
